function playsimulationFINAL(profits,startyear,player,comp,loadgrowth,N,bus_old,gen_old,gencost_old,MW_ADD,bidprice,mc,priceforecast,loadforecast,year,baseMVA,branch_old,area)
format short g;
clc
fprintf('\n');
fprintf('\n');
fprintf('\n Final Profit is: %s',num2str(profits));
fprintf('\n');
fprintf('\n');
pause(5);
clc;

return;